class Routes{
static String loginScreen="/";
static String registerscreen="/register";
static String userhomeScreen="/home";
static String adminhomescreen="/adminhome";
static String splashscreen="/splash";
static String question="/question";
static String result="/result";
static String password="/password";
}
