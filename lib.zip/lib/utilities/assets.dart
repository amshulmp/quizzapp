class Assets{
  static String logo="assets/logo.png";
  static String background="assets/background.jpg";
  static String background2="assets/background2.jpg";
}